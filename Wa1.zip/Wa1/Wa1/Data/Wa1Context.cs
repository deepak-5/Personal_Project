﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Wa1.Models;

namespace Wa1.Data
{
    public class Wa1Context : DbContext
    {
        public Wa1Context (DbContextOptions<Wa1Context> options)
            : base(options)
        {
        }

        public DbSet<Wa1.Models.Movie> Movie { get; set; } = default!;
    }
}
