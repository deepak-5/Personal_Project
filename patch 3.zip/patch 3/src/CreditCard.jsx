import React, { useState } from 'react';
import './CreditCard.css';

const CreditCard = () => {
  const [cards, setCards] = useState([]);
  const [id, setId] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();

    const formData = {
      id,
      cardNumber,
      expiryDate,
    };

    // Store the current card data in the cards state array
    setCards([...cards, formData]);

    // Reset the form fields
    setId('');
    setCardNumber('');
    setExpiryDate('');

    alert('Form submitted successfully!');
  };

  const handleSaveAndContinue = () => {
    // Save the form data to local database

    // Redirect to the next page or perform any necessary actions
    window.location.href = 'Assets';
  };

  const handlePrevious = () => {
    window.location.href = 'Identity';
  };

  const handleAddAnotherCard = () => {
    // Create a new card object with the current field values
    const newCard = {
      id,
      cardNumber,
      expiryDate,
    };

    // Store the new card data in the cards state array
    setCards([...cards, newCard]);

    // Reset the form fields
    setId('');
    setCardNumber('');
    setExpiryDate('');
  };

  return (
    <div>
      <h1>Credit Card Form</h1>
      <form onSubmit={handleSubmit}>
        <label>ID Number:</label>
        <input
          type="number"
          value={id}
          onChange={(e) => setId(e.target.value)}
          required
        />

        <label>Credit Card Number:</label>
        <input
          type="text"
          value={cardNumber}
          onChange={(e) => setCardNumber(e.target.value)}
          required
        />

        <label>Expiry Date:</label>
        <input
          type="text"
          value={expiryDate}
          onChange={(e) => setExpiryDate(e.target.value)}
          required
        />

        <div>
          <button type="button" onClick={handlePrevious}>
            Previous
          </button>
          <button type="button" onClick={handleSaveAndContinue}>
            Save &amp; Continue
          </button>
          <button type="button" onClick={handleAddAnotherCard}>
            Add Another Card
          </button>
        </div>
      </form>
      {cards.length > 0 && (
 <div className="stored-cards">
 <h3>Stored Cards</h3>
 <ul>
   {cards.map((card, index) => (
     <li key={index}>
       Card {index + 1}: ID - {card.id}, Card Number - {card.cardNumber}, Expiry Date - {card.expiryDate}
     </li>
   ))}
 </ul>
</div>
)}
</div>
  );
};

export default CreditCard;
