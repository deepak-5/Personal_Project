﻿using System;
using System.Threading.Tasks;
using MyBackgroundTasksProject.BackgroundTasks;

namespace MyBackgroundTasksProject
{
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("Press any key to stop the tasks...");

            // Start and stop the tasks in the desired sequence
            await StartAndStopTasksInSequence();

            Console.WriteLine("All tasks have been stopped.");
        }

        static async Task StartAndStopTasksInSequence()
        {
            var timedTask = new TimedBackgroundTask();
            var asyncTimedTask = new AsyncTimedBackgroundTask();
            var queuedTask = new QueuedBackgroundTask();
            var scopedTask = new ScopedBackgroundTask();

            // Start TimedBackgroundTask
            var timedTaskHandler = Task.Run(() => timedTask.StartAsync());
            await Task.Delay(5000); // Let it run for 5 seconds

            // Stop TimedBackgroundTask
            timedTask.Stop();
            await timedTaskHandler;

            // Start AsyncTimedBackgroundTask
            var asyncTimedTaskHandler = Task.Run(() => asyncTimedTask.StartAsync());
            await Task.Delay(5000); // Let it run for 5 seconds

            // Stop AsyncTimedBackgroundTask
            asyncTimedTask.Stop();
            await asyncTimedTaskHandler;

            // Enqueue tasks for QueuedBackgroundTask
            queuedTask.EnqueueTask("Task 1");
            queuedTask.EnqueueTask("Task 2");
            queuedTask.EnqueueTask("Task 3");

            // Start QueuedBackgroundTask
            var queuedTaskHandler = Task.Run(() => queuedTask.StartAsync());
            await Task.Delay(5000); // Let it run for 5 seconds

            // Stop QueuedBackgroundTask
            queuedTask.Stop();
            await queuedTaskHandler;

            // Start ScopedBackgroundTask
            var scopedTaskHandler = Task.Run(() => scopedTask.StartAsync());
            await Task.Delay(5000); // Let it run for 5 seconds

            // Stop ScopedBackgroundTask
            scopedTask.Stop();
            await scopedTaskHandler;
        }
    }
}
