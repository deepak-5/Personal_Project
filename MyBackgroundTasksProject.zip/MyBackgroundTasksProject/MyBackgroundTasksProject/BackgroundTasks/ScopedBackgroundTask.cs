﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace MyBackgroundTasksProject.BackgroundTasks
{
    public class ScopedBackgroundTask
    {
        private int counter = 0;
        private CancellationTokenSource _cancellationTokenSource;

        public async Task StartAsync()
        {
            _cancellationTokenSource = new CancellationTokenSource();

            while (!_cancellationTokenSource.Token.IsCancellationRequested)
            {
                counter++;
                Console.WriteLine($"ScopedBackgroundTask counter: {counter}");
                await Task.Delay(1000, _cancellationTokenSource.Token);
            }
        }

        public void Stop()
        {
            _cancellationTokenSource.Cancel();
        }
    }
}
