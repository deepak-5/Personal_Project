﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace MyBackgroundTasksProject.BackgroundTasks
{
    public class AsyncTimedBackgroundTask
    {
        private CancellationTokenSource _cancellationTokenSource;

        public async Task StartAsync()
        {
            _cancellationTokenSource = new CancellationTokenSource();

            while (!_cancellationTokenSource.Token.IsCancellationRequested)
            {
                Console.WriteLine("AsyncTimedBackgroundTask is running...");
                await SomeAsyncOperation(); // An example asynchronous operation
                await Task.Delay(3000, _cancellationTokenSource.Token); // Run every 3 seconds or until canceled
            }
        }

        private async Task SomeAsyncOperation()
        {
            // Simulate an asynchronous operation
            await Task.Delay(1000);
            Console.WriteLine("Async operation complete.");
        }

        public void Stop()
        {
            _cancellationTokenSource.Cancel();
        }
    }
}
