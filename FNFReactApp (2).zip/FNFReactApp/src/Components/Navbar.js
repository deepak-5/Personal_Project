import React from 'react';
function NavBar() {
 return (
 <nav>
 <ul>
 <li><a href="/">Home</a></li>
 <li><a href="/LoanPage">LoanPage</a></li>
 <li><a href="/Status">Status</a></li>
 <li><a href="/calculator">Calculator</a></li>
 <li><a href="/Chatbot">Chatbot</a></li>
 <li><a href="/faq">Faq</a></li>

 
 </ul>
 </nav>
 );
}
export default NavBar;
