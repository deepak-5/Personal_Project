import React, { useState } from 'react';
import './Form.css';

const PropertyDetails = () => {
  const [appId, setAppId] = useState('');
  const [propertyValue, setPropertyValue] = useState('');
  const [expectedLoan, setExpectedLoan] = useState('');
  const [propertyAddress, setPropertyAddress] = useState('');
  const [cibilScore, setCibilScore] = useState('');
  const [lawyerStatus, setLawyerStatus] = useState('');
  const [dateApplied, setDateApplied] = useState('');
  const [error, setError] = useState('');
  const [notification, setNotification] = useState('');

  const generateRandomId = () => {
    const min = 1000000000; // Minimum 10-digit number
    const max = 9999999999; // Maximum 10-digit number
    return Math.floor(Math.random() * (max - min + 1)) + min;
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    // Generate random ID
    const generatedId = generateRandomId();
    alert(generatedId)
    // Perform submit action
    const formData = {
      appId: generatedId,
      propertyValue,
      expectedLoan,
      propertyAddress,
      cibilScore,
      lawyerStatus,
      dateApplied,
    };

    fetch('https://mortgageautomationgroupa.azurewebsites.net/property', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(formData),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log('Form submitted successfully!', data);
        setNotification('Form submitted successfully!');
      })
      .catch((error) => {
        console.error('Error submitting form:', error);
        setError('Form submission failed!');
      });
  };

  const handleSaveAndContinue = () => {
    // Save the form data to local database
    handleSubmit(new Event('submit'));
  };

  const handlePrevious = () => {
    // Redirect to the previous page or perform any necessary actions
    // For demonstration purposes, I'm simply logging a message here
    window.location.href = '/loanpage/Investmet';
  };

  return (
    <div>
      <h1>Property Details</h1>
      {error && <div style={{ color: 'red' }}>{error}</div>}
      {notification && <div style={{ color: 'green' }}>{notification}</div>}
      <form>
        <label>App ID:</label>
        <input
          type="number"
          value={appId}
          onChange={(e) => setAppId(e.target.value)}
          required
        />

        <label>Property Value:</label>
        <input
          type="number"
          step="0.01"
          value={propertyValue}
          onChange={(e) => setPropertyValue(e.target.value)}
          required
        />

        <label>Expected Loan:</label>
        <input
          type="number"
          step="0.01"
          value={expectedLoan}
          onChange={(e) => setExpectedLoan(e.target.value)}
          required
        />

        <label>Property Address:</label>
        <input
          type="text"
          value={propertyAddress}
          onChange={(e) => setPropertyAddress(e.target.value)}
          required
        />

        <label>Cibil Score:</label>
        <input
          type="number"
          value={cibilScore}
          onChange={(e) => setCibilScore(e.target.value)}
          required
        />

        <label>Lawyer Status:</label>
        <input
          type="text"
          value={lawyerStatus}
          onChange={(e) => setLawyerStatus(e.target.value)}
          required
        />

        <label>Date Applied:</label>
        <input
          type="text"
          value={dateApplied}
          onChange={(e) => setDateApplied(e.target.value)}
          required
        />

        <div>
          <button type="submit" onClick={handlePrevious}>
            Previous
          </button>
          <button type="submit" onClick={handleSubmit}>
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};

export default PropertyDetails;
