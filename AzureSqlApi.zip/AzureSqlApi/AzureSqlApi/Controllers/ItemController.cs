﻿// AzureSqlApi/Controllers/ItemController.cs
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AzureSqlApi.Models;
using AzureSqlApi.Services;
using AzureSqlApi.Commands;
using AzureSqlApi.Queries;
using AzureSqlApi.Queries;
using AzureSqlApi.Services;

namespace AzureSqlApi.Controllers
{
    [ApiController]
    [Route("api/items")]
    public class ItemController : ControllerBase
    {
        private readonly IItemService _itemService;

        public ItemController(IItemService itemService)
        {
            _itemService = itemService;
        }

        [HttpGet]
        public async Task<ActionResult<List<Item>>> GetAllItems()
        {
            var query = new GetAllItemsQuery();
            var items = await _itemService.GetAllItemsAsync(query);
            return Ok(items);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Item>> GetItemById(int id)
        {
            var query = new GetItemQuery { Id = id };
            var item = await _itemService.GetItemByIdAsync(query);
            if (item == null)
            {
                return NotFound();
            }

            return Ok(item);
        }

        [HttpPost]
        public async Task<ActionResult<Item>> CreateItem(CreateItemCommand command)
        {
            var createdItemId = await _itemService.CreateItemAsync(command);
            return CreatedAtAction(nameof(GetItemById), new { id = createdItemId }, null);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateItem(int id, UpdateItemCommand command)
        {
            command.Id = id;
            try
            {
                await _itemService.UpdateItemAsync(command);
                return NoContent();
            }
            catch (InvalidOperationException ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteItem(int id)
        {
            var command = new DeleteItemCommand { Id = id };
            await _itemService.DeleteItemAsync(command);
            return NoContent();
        }
    }
}
