﻿// AzureSqlApi/CommandHandlers/IDeleteItemCommandHandler.cs
using System.Threading.Tasks;
using AzureSqlApi.Commands;

namespace AzureSqlApi.CommandHandlers
{
    public interface IDeleteItemCommandHandler
    {
        Task HandleAsync(DeleteItemCommand command);
    }
}
