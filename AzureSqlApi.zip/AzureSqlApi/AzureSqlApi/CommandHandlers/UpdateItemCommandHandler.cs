﻿using System;
using System.Threading.Tasks;
using AzureSqlApi.Commands;
using AzureSqlApi.Data;
using Microsoft.EntityFrameworkCore;

namespace AzureSqlApi.CommandHandlers
{
    public class UpdateItemCommandHandler : IUpdateItemCommandHandler
    {
        private readonly ApplicationDbContext _dbContext;

        public UpdateItemCommandHandler(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task HandleAsync(UpdateItemCommand command)
        {
            var existingItem = await _dbContext.Items.FindAsync(command.Id);

            if (existingItem == null)
            {
                throw new InvalidOperationException("Item not found.");
            }

            existingItem.Name = command.Name;
            existingItem.Description = command.Description;
            // Update other properties as needed

            await _dbContext.SaveChangesAsync();
        }
    }
}
