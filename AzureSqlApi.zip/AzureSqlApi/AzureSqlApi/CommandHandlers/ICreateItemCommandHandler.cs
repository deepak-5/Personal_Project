﻿// AzureSqlApi/CommandHandlers/ICreateItemCommandHandler.cs
using System.Threading.Tasks;
using AzureSqlApi.Commands;

namespace AzureSqlApi.CommandHandlers
{
    public interface ICreateItemCommandHandler
    {
        Task<int> HandleAsync(CreateItemCommand command);
    }
}
