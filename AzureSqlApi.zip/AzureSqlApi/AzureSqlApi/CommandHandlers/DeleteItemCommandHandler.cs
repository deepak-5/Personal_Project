﻿using System;
using System.Threading.Tasks;
using AzureSqlApi.Commands;
using AzureSqlApi.Data;
using Microsoft.EntityFrameworkCore;

namespace AzureSqlApi.CommandHandlers
{
    public class DeleteItemCommandHandler : IDeleteItemCommandHandler
    {
        private readonly ApplicationDbContext _dbContext;

        public DeleteItemCommandHandler(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task HandleAsync(DeleteItemCommand command)
        {
            var existingItem = await _dbContext.Items.FindAsync(command.Id);

            if (existingItem == null)
            {
                throw new InvalidOperationException("Item not found.");
            }

            _dbContext.Items.Remove(existingItem);
            await _dbContext.SaveChangesAsync();
        }
    }
}
