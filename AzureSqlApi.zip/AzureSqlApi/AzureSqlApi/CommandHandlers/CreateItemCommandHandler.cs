﻿using System.Threading.Tasks;
using AzureSqlApi.Commands;
using AzureSqlApi.Data;
using AzureSqlApi.Models;

namespace AzureSqlApi.CommandHandlers
{
    public class CreateItemCommandHandler : ICreateItemCommandHandler
    {
        private readonly ApplicationDbContext _dbContext;

        public CreateItemCommandHandler(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<int> HandleAsync(CreateItemCommand command)
        {
            var newItem = new Item
            {
                Name = command.Name,
                Description = command.Description
                // Set other properties as needed
            };

            _dbContext.Items.Add(newItem);
            await _dbContext.SaveChangesAsync();

            return newItem.Id;
        }
    }
}
