﻿// AzureSqlApi/CommandHandlers/IUpdateItemCommandHandler.cs
using System.Threading.Tasks;
using AzureSqlApi.Commands;

namespace AzureSqlApi.CommandHandlers
{
    public interface IUpdateItemCommandHandler
    {
        Task HandleAsync(UpdateItemCommand command);
    }
}
