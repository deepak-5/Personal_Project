﻿// AzureSqlApi/Commands/DeleteItemCommand.cs
namespace AzureSqlApi.Commands
{
    public class DeleteItemCommand
    {
        public int Id { get; set; }
    }
}
