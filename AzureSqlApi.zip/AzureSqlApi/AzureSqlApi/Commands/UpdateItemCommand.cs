﻿// AzureSqlApi/Commands/UpdateItemCommand.cs
using System.ComponentModel.DataAnnotations;

namespace AzureSqlApi.Commands
{
    public class UpdateItemCommand
    {
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
