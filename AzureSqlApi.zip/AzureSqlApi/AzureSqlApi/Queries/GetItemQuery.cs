﻿// AzureSqlApi/Queries/GetItemQuery.cs
namespace AzureSqlApi.Queries
{
    public class GetItemQuery
    {
        public int Id { get; set; }
    }
}
