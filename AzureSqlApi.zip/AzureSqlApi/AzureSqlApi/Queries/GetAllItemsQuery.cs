﻿using System.Collections.Generic;
using AzureSqlApi.DTOs;
using MediatR; // Make sure to add the MediatR namespace if you're using MediatR for CQRS

namespace AzureSqlApi.Queries
{
    public class GetAllItemsQuery : IRequest<List<ItemDTO>> // You may have a DTO class for your items
    {
        // You can add properties to the query if needed (e.g., filtering options)
    }
}
