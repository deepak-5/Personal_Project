﻿// AzureSqlApi/QueryHandlers/IGetAllItemsQueryHandler.cs
using System.Collections.Generic;
using System.Threading.Tasks;
using AzureSqlApi.Queries;
using AzureSqlApi.Models;
using AzureSqlApi.Queries;

namespace AzureSqlApi.QueryHandlers
{
    public interface IGetAllItemsQueryHandler
    {
        Task<List<Item>> HandleAsync(GetAllItemsQuery query);
    }
}
