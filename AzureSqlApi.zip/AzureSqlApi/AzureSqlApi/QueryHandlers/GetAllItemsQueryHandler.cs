﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AzureSqlApi.Queries;
using AzureSqlApi.Data;
using AzureSqlApi.Models;
using Microsoft.EntityFrameworkCore;

namespace AzureSqlApi.QueryHandlers
{
    public class GetAllItemsQueryHandler : IGetAllItemsQueryHandler
    {
        private readonly ApplicationDbContext _dbContext;

        public GetAllItemsQueryHandler(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<List<Item>> HandleAsync(GetAllItemsQuery query)
        {
            var items = await _dbContext.Items.ToListAsync();

            return items;
        }
    }
}
