﻿// AzureSqlApi/QueryHandlers/IGetItemQueryHandler.cs
using System.Threading.Tasks;
using AzureSqlApi.Models;
using AzureSqlApi.Queries;

namespace AzureSqlApi.QueryHandlers
{
    public interface IGetItemQueryHandler
    {
        Task<Item> HandleAsync(GetItemQuery query);
    }
}
