﻿using System.Threading.Tasks;
using AzureSqlApi.Queries;
using AzureSqlApi.Data;
using AzureSqlApi.Models;
using Microsoft.EntityFrameworkCore;

namespace AzureSqlApi.QueryHandlers
{
    public class GetItemQueryHandler : IGetItemQueryHandler
    {
        private readonly ApplicationDbContext _dbContext;

        public GetItemQueryHandler(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<Item> HandleAsync(GetItemQuery query)
        {
            var item = await _dbContext.Items.FindAsync(query.Id);

            if (item == null)
            {
                // Handle item not found
                return null;
            }

            return item;
        }
    }
}
