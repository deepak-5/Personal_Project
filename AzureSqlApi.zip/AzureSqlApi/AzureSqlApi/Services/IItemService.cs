﻿// AzureSqlApi/Services/IItemService.cs
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AzureSqlApi.Models;
using AzureSqlApi.Commands;
using AzureSqlApi.Queries;
using AzureSqlApi.Queries;

namespace AzureSqlApi.Services
{
    public interface IItemService
    {
        Task<int> CreateItemAsync(CreateItemCommand command);
        Task UpdateItemAsync(UpdateItemCommand command);
        Task<Item> GetItemByIdAsync(GetItemQuery query);
        Task<List<Item>> GetAllItemsAsync(GetAllItemsQuery query);
        Task DeleteItemAsync(DeleteItemCommand command);
    }
}
