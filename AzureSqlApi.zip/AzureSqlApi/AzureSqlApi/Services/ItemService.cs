﻿// AzureSqlApi/Services/ItemService.cs
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AzureSqlApi.Models;
using AzureSqlApi.Commands;
using AzureSqlApi.Queries;
using AzureSqlApi.CommandHandlers;
using AzureSqlApi.QueryHandlers;
using AzureSqlApi.Queries;


namespace AzureSqlApi.Services
{
    public class ItemService : IItemService
    {
        private readonly ICreateItemCommandHandler _createItemCommandHandler;
        private readonly IUpdateItemCommandHandler _updateItemCommandHandler;
        private readonly IDeleteItemCommandHandler _deleteItemCommandHandler;
        private readonly IGetItemQueryHandler _getItemQueryHandler;
        private readonly IGetAllItemsQueryHandler _getAllItemsQueryHandler;

        public ItemService(
            ICreateItemCommandHandler createItemCommandHandler,
            IUpdateItemCommandHandler updateItemCommandHandler,
            IDeleteItemCommandHandler deleteItemCommandHandler,
            IGetItemQueryHandler getItemQueryHandler,
            IGetAllItemsQueryHandler getAllItemsQueryHandler)
        {
            _createItemCommandHandler = createItemCommandHandler;
            _updateItemCommandHandler = updateItemCommandHandler;
            _deleteItemCommandHandler = deleteItemCommandHandler;
            _getItemQueryHandler = getItemQueryHandler;
            _getAllItemsQueryHandler = getAllItemsQueryHandler;
        }

        public async Task<int> CreateItemAsync(CreateItemCommand command)
        {
            // Add business logic and validation as needed
            return await _createItemCommandHandler.HandleAsync(command);
        }

        public async Task UpdateItemAsync(UpdateItemCommand command)
        {
            // Add business logic and validation as needed
            await _updateItemCommandHandler.HandleAsync(command);
        }

        public async Task<Item> GetItemByIdAsync(GetItemQuery query)
        {
            return await _getItemQueryHandler.HandleAsync(query);
        }

        public async Task<List<Item>> GetAllItemsAsync(GetAllItemsQuery query)
        {
            return await _getAllItemsQueryHandler.HandleAsync(query);
        }

        public async Task DeleteItemAsync(DeleteItemCommand command)
        {
            await _deleteItemCommandHandler.HandleAsync(command);
        }
    }
}
