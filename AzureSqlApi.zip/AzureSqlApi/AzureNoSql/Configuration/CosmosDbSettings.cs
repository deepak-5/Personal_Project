﻿namespace AzureNoSql.Configuration // or AzureNoSql.Settings, match your folder name
{
    public class CosmosDbSettings
    {
        public string CosmosConnectionString { get; set; }
        public string DatabaseName { get; set; }
        public string ContainerName { get; set; }
    }
}
