﻿using AzureNoSql.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AzureNoSql.Data.Repositories
{
    public interface IDocumentRepository
    {
        Task<Document> CreateAsync(Document document);
        Task<Document> GetByIdAsync(string id);
        Task<IEnumerable<Document>> GetAllAsync();
        Task<Document> UpdateAsync(Document document);
        Task DeleteAsync(string id);
    }
}
