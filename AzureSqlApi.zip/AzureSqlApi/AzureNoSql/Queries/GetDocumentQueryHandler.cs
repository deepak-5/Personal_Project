﻿using AzureNoSql.Models;
using AzureNoSql.Data.Repositories;
using MediatR;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace AzureNoSql.Handlers.Queries
{
    public class GetDocumentQuery : IRequest<Document>
    {
        public string DocumentId { get; set; }
    }

    public class GetDocumentQueryHandler : IRequestHandler<GetDocumentQuery, Document>
    {
        private readonly DocumentRepository _documentRepository;

        public GetDocumentQueryHandler(DocumentRepository documentRepository)
        {
            _documentRepository = documentRepository ?? throw new ArgumentNullException(nameof(documentRepository));
        }

        public async Task<Document> Handle(GetDocumentQuery request, CancellationToken cancellationToken)
        {
            // Implement logic to retrieve a document by ID
            return await _documentRepository.GetByIdAsync(request.DocumentId);
        }
    }
}

