﻿using AzureNoSql.Models;
using AzureNoSql.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AzureNoSql.Controllers
{
    [Route("api/documents")]
    [ApiController]
    public class DocumentController : ControllerBase
    {
        private readonly DocumentService _documentService;

        public DocumentController(DocumentService documentService)
        {
            _documentService = documentService ?? throw new ArgumentNullException(nameof(documentService));
        }

        [HttpPost]
        public async Task<ActionResult<Document>> CreateDocumentAsync(Document document)
        {
            var createdDocument = await _documentService.CreateDocumentAsync(document);
            return Ok(createdDocument);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Document>> GetDocumentByIdAsync(string id)
        {
            var document = await _documentService.GetDocumentByIdAsync(id);
            if (document == null)
            {
                return NotFound();
            }
            return Ok(document);
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Document>>> GetAllDocumentsAsync()
        {
            var documents = await _documentService.GetAllDocumentsAsync();
            return Ok(documents);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateDocumentAsync(string id, Document document)
        {
            if (id != document.id)
            {
                return BadRequest();
            }
            var updatedDocument = await _documentService.UpdateDocumentAsync(document);
            return Ok(updatedDocument);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDocumentAsync(string id)
        {
            await _documentService.DeleteDocumentAsync(id);
            return NoContent();
        }
    }
}
