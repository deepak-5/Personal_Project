﻿using AzureNoSql.Models;
using AzureNoSql.Data.Repositories;
using MediatR;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace AzureNoSql.Handlers.Commands
{
    public class UpdateDocumentCommand : IRequest<Document>
    {
        public Document Document { get; set; }
    }

    public class UpdateDocumentCommandHandler : IRequestHandler<UpdateDocumentCommand, Document>
    {
        private readonly DocumentRepository _documentRepository;

        public UpdateDocumentCommandHandler(DocumentRepository documentRepository)
        {
            _documentRepository = documentRepository ?? throw new ArgumentNullException(nameof(documentRepository));
        }

        public async Task<Document> Handle(UpdateDocumentCommand request, CancellationToken cancellationToken)
        {
            // Implement logic to update a document
            return await _documentRepository.UpdateAsync(request.Document);
        }
    }
}
