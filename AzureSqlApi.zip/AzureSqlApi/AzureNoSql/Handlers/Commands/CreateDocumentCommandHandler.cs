﻿using AzureNoSql.Models;
using AzureNoSql.Data.Repositories;
using MediatR;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace AzureNoSql.Handlers.Commands
{
    public class CreateDocumentCommand : IRequest<Document>
    {
        public Document Document
        {
            get; set;
        }

        public class CreateDocumentCommandHandler : IRequestHandler<CreateDocumentCommand, Document>
        {
            private readonly DocumentRepository _documentRepository;

            public CreateDocumentCommandHandler(DocumentRepository documentRepository)
            {
                _documentRepository = documentRepository ?? throw new ArgumentNullException(nameof(documentRepository));
            }

            public async Task<Document> Handle(CreateDocumentCommand request, CancellationToken cancellationToken)
            {
                // Implement logic to create a document
                return await _documentRepository.CreateAsync(request.Document);
            }
        }
    }
}

