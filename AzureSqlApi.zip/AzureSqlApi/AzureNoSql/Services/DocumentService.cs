﻿using AzureNoSql.Data.Repositories;
using AzureNoSql.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AzureNoSql.Services
{
    public class DocumentService
    {
        private readonly DocumentRepository _documentRepository;

        public DocumentService(DocumentRepository documentRepository)
        {
            _documentRepository = documentRepository ?? throw new ArgumentNullException(nameof(documentRepository));
        }

        public async Task<Document> CreateDocumentAsync(Document document)
        {
            return await _documentRepository.CreateAsync(document);
        }

        public async Task<Document> GetDocumentByIdAsync(string id)
        {
            return await _documentRepository.GetByIdAsync(id);
        }

        public async Task<IEnumerable<Document>> GetAllDocumentsAsync()
        {
            return await _documentRepository.GetAllAsync();
        }

        public async Task<Document> UpdateDocumentAsync(Document document)
        {
            return await _documentRepository.UpdateAsync(document);
        }

        public async Task DeleteDocumentAsync(string id)
        {
            await _documentRepository.DeleteAsync(id);
        }
    }
}
