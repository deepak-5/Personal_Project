﻿using Microsoft.EntityFrameworkCore;
using WebApplication1.Models;

namespace WebApplication1.Data
{
    // Represents the application's database context.
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        // Define DbSet properties for your data models here

        // DbSet for the 'Item' data model
        public DbSet<Item> Items { get; set; }

        // Add DbSet properties for other data models as needed

        // Configures the database schema, relationships, and other model-specific settings.
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
    }
}
