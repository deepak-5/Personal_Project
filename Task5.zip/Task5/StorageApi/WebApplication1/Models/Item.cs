﻿namespace WebApplication1.Models
{
    using System.ComponentModel.DataAnnotations;

    // Represents the 'Item' data model.
    public class Item
    {
        // Primary key for the 'Item' data model.
        [Key]
        public int Id { get; set; }

        // The name of the item (required field).
        [Required]
        public string Name { get; set; }

        // Description of the item (optional field).
        public string? Description { get; set; }

        // Add other properties as needed

        // Additional properties, methods, and validation attributes can be added here.
    }
}
