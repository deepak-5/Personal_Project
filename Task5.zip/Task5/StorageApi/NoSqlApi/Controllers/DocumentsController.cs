﻿using Microsoft.AspNetCore.Mvc;
using NoSqlApi.Data;
using NoSqlApi.Interfaces;
using NoSqlApi.Models;
using System.Threading.Tasks;

namespace NoSqlApi.Controllers
{
    /// <summary>
    /// Controller for managing documents.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class DocumentsController : ControllerBase
    {
        private readonly IDocumentRepository _repository;

        public DocumentsController(IDocumentRepository repository)
        {
            _repository = repository;
        }

        /// <summary>
        /// Retrieves a list of documents.
        /// </summary>
        /// <returns>A list of documents.</returns>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Document>>> GetAllDocuments()
        {
            // Retrieve all documents asynchronously.
            var documents = await _repository.GetAllDocumentsAsync();
            return Ok(documents); // Return a 200 OK response with the list of documents as the content.
        }

        /// <summary>
        /// Retrieves a specific document by its ID.
        /// </summary>
        /// <param name="id">The ID of the document to retrieve.</param>
        /// <returns>The requested document or a NotFound response if not found.</returns>
        [HttpGet("{id}")]
        public async Task<ActionResult<Document>> GetDocument(string id)
        {
            // Retrieve a document by ID asynchronously.
            var document = await _repository.GetDocumentAsync(id);
            if (document == null)
            {
                return NotFound(); // Return a 404 Not Found response if the document is not found.
            }
            return Ok(document); // Return a 200 OK response with the document as the content.
        }

        /// <summary>
        /// Creates a new document.
        /// </summary>
        /// <param name="document">The document to create.</param>
        /// <returns>A CreatedAtAction response with the created document.</returns>
        [HttpPost]
        public async Task<ActionResult<Document>> CreateDocument([FromBody] Document document)
        {
            if (document == null)
            {
                return BadRequest(); // Return a 400 Bad Request response if the request body is invalid.
            }

            // Create a new document asynchronously.
            await _repository.CreateDocumentAsync(document);
            return CreatedAtAction(nameof(GetDocument), new { id = document.id }, document);
        }

        /// <summary>
        /// Updates an existing document by its ID.
        /// </summary>
        /// <param name="id">The ID of the document to update.</param>
        /// <param name="document">The updated document data.</param>
        /// <returns>NoContent if successful, BadRequest if the ID doesn't match any existing document.</returns>
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateDocument(string id, [FromBody] Document document)
        {
            if (document == null || id != document.id)
            {
                return BadRequest();
            }

            // Check if the existing document exists.
            var existingDocument = await _repository.GetDocumentAsync(id);
            if (existingDocument == null)
            {
                return NotFound(); // Return a 404 Not Found response if the document is not found.
            }

            // Update the document asynchronously.
            await _repository.UpdateDocumentAsync(document);
            return NoContent(); // Return a 204 No Content response after a successful update.
        }


        /// <summary>
        /// Deletes a document by its ID.
        /// </summary>
        /// <param name="id">The ID of the document to delete.</param>
        /// <returns>NoContent if successful, NotFound if the document does not exist.</returns>
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDocument(string id)
        {
            // Check if the existing document exists.
            var existingDocument = await _repository.GetDocumentAsync(id);
            if (existingDocument == null)
            {
                return NotFound(); // Return a 404 Not Found response if the document is not found.
            }

            // Delete the document asynchronously.
            await _repository.DeleteDocumentAsync(id);
            return NoContent(); // Return a 204 No Content response after a successful delete.
        }
    }
}
