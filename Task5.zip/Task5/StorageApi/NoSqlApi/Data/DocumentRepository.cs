﻿using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NoSqlApi.Models;
using NoSqlApi.Interfaces;

namespace NoSqlApi.Data
{
    /// <summary>
    /// Repository for managing documents in Cosmos DB.
    /// </summary>
    public class DocumentRepository : IDocumentRepository
    {
        private readonly Container _container;

        public DocumentRepository(IConfiguration configuration)
        {
            var cosmosDbSettings = configuration.GetSection("CosmosDbSettings");
            var cosmosConnectionString = cosmosDbSettings["cosmosConnectionString"];
            var cosmosClient = new CosmosClient(cosmosConnectionString);
            var databaseName = cosmosDbSettings["DatabaseName"];
            var containerName = cosmosDbSettings["ContainerName"];
            _container = cosmosClient.GetContainer(databaseName, containerName);
        }

        /// <summary>
        /// Create a document in Cosmos DB.
        /// </summary>
        /// <param name="document">The document to create.</param>
        public async Task CreateDocumentAsync(Document document)
        {
            await _container.CreateItemAsync(document, new PartitionKey(document.id));
        }

        /// <summary>
        /// Get a document by id from Cosmos DB.
        /// </summary>
        /// <param name="id">The ID of the document to retrieve.</param>
        /// <returns>The requested document or null if not found.</returns>
        public async Task<Document> GetDocumentAsync(string id)
        {
            try
            {
                var response = await _container.ReadItemAsync<Document>(id, new PartitionKey(id));
                return response.Resource;
            }
            catch (CosmosException ex) when (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                return null; // Document not found
            }
        }

        /// <summary>
        /// Update a document in Cosmos DB.
        /// </summary>
        /// <param name="document">The updated document.</param>
        public async Task UpdateDocumentAsync(Document document)
        {
            await _container.ReplaceItemAsync(document, document.id);
        }

        /// <summary>
        /// Delete a document from Cosmos DB.
        /// </summary>
        /// <param name="id">The ID of the document to delete.</param>
        public async Task DeleteDocumentAsync(string id)
        {
            await _container.DeleteItemAsync<Document>(id, new PartitionKey(id));
        }

        /// <summary>
        /// Get all documents from Cosmos DB.
        /// </summary>
        /// <returns>A list of documents.</returns>
        public async Task<IEnumerable<Document>> GetAllDocumentsAsync()
        {
            var sqlQuery = new QueryDefinition("SELECT * FROM c");
            var documents = new List<Document>();

            using (var resultSetIterator = _container.GetItemQueryIterator<Document>(sqlQuery))
            {
                while (resultSetIterator.HasMoreResults)
                {
                    var response = await resultSetIterator.ReadNextAsync();
                    documents.AddRange(response.ToList());
                }
            }

            return documents;
        }

        // Additional methods for querying or listing documents can be added as needed
    }
}
