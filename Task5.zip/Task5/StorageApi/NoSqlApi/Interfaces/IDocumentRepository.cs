﻿using NoSqlApi.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NoSqlApi.Interfaces
{
    public interface IDocumentRepository
    {
        Task<IEnumerable<Document>> GetAllDocumentsAsync();
        Task<Document> GetDocumentAsync(string id);
        Task CreateDocumentAsync(Document document);
        Task UpdateDocumentAsync(Document document);
        Task DeleteDocumentAsync(string id);
    }
}
