﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using WebApplication1.Controllers;
using WebApplication1.Data;
using WebApplication1.Models;
using Xunit;

public class ItemsControllerTests : IDisposable
{
    private readonly ApplicationDbContext _dbContext;

    public ItemsControllerTests()
    {
        // Configure DbContext options to use the in-memory database.
        var options = new DbContextOptionsBuilder<ApplicationDbContext>()
            .UseInMemoryDatabase(databaseName: "test_database")
            .Options;

        // Create a new ApplicationDbContext instance using the in-memory database.
        _dbContext = new ApplicationDbContext(options);
    }

    [Fact]
    public async Task GetItems_ReturnsOkResultWithListOfItems()
    {
        // Arrange
        var items = new List<Item>
        {
            new Item { Id = 1, Name = "Item 1", Description = "Description 1" },
            new Item { Id = 2, Name = "Item 2", Description = "Description 2" }
        };

        // Seed the in-memory database with sample data.
        await _dbContext.Database.EnsureDeletedAsync(); // Delete any existing in-memory database.
        await _dbContext.Database.EnsureCreatedAsync(); // Create a new in-memory database.
        await _dbContext.Items.AddRangeAsync(items);
        await _dbContext.SaveChangesAsync();

        // Create the ItemsController using the in-memory database context.
        var controller = new ItemsController(_dbContext);

        // Act
        var result = await controller.GetItems();

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var model = Assert.IsAssignableFrom<IEnumerable<Item>>(okResult.Value);
        Assert.Equal(2, model.Count());
    }

    [Fact]
    public async Task GetItem_WithValidId_ReturnsOkResultWithItem()
    {
        // Arrange
        var item = new Item { Id = 1, Name = "Item 1", Description = "Description 1" };

        // Seed the in-memory database with the test item.
        await _dbContext.Database.EnsureDeletedAsync();
        await _dbContext.Database.EnsureCreatedAsync();
        await _dbContext.Items.AddAsync(item);
        await _dbContext.SaveChangesAsync();

        // Create the ItemsController using the in-memory database context.
        var controller = new ItemsController(_dbContext);

        // Act
        var result = await controller.GetItem(1);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var model = Assert.IsType<Item>(okResult.Value);
        Assert.Equal(1, model.Id);
    }

    [Fact]
    public async Task GetItem_WithInvalidId_ReturnsNotFoundResult()
    {
        // Arrange
        var invalidId = 999; // An ID that does not exist in the database.

        // Create the ItemsController using the in-memory database context.
        var controller = new ItemsController(_dbContext);

        // Act
        var result = await controller.GetItem(invalidId);

        // Assert
        Assert.IsType<NotFoundResult>(result.Result);
    }


    [Fact]
    public async Task CreateItem_WithValidItem_ReturnsCreatedAtActionResult()
    {
        // Arrange
        var item = new Item { Id = 1, Name = "Item 1", Description = "Description 1" };

        // Create the ItemsController using the in-memory database context.
        var controller = new ItemsController(_dbContext);

        // Act
        var result = await controller.CreateItem(item);

        // Assert
        Assert.IsType<ActionResult<Item>>(result);
    }

    [Fact]
    public async Task UpdateItem_WithValidId_ReturnsNoContentResult()
    {
        // Arrange
        var item = new Item { Id = 1, Name = "Item 1", Description = "Description 1" };

        // Seed the in-memory database with the test item.
        await _dbContext.Database.EnsureDeletedAsync();
        await _dbContext.Database.EnsureCreatedAsync();
        await _dbContext.Items.AddAsync(item);
        await _dbContext.SaveChangesAsync();

        // Create the ItemsController using the in-memory database context.
        var controller = new ItemsController(_dbContext);

        // Act
        var result = await controller.UpdateItem(1, item);

        // Assert
        Assert.IsType<NoContentResult>(result);
    }

    [Fact]
    public async Task UpdateItem_WithInvalidId_ReturnsBadRequestResult()
    {
        // Arrange
        var item = new Item { Id = 1, Name = "Item 1", Description = "Description 1" };

        // Create the ItemsController using the in-memory database context.
        var controller = new ItemsController(_dbContext);

        // Act
        var result = await controller.UpdateItem(2, item);

        // Assert
        Assert.IsType<BadRequestResult>(result);
    }

    [Fact]
    public async Task DeleteItem_WithValidId_ReturnsNoContentResult()
    {
        // Arrange
        var item = new Item { Id = 1, Name = "Item 1", Description = "Description 1" };

        // Seed the in-memory database with the test item.
        await _dbContext.Database.EnsureDeletedAsync();
        await _dbContext.Database.EnsureCreatedAsync();
        await _dbContext.Items.AddAsync(item);
        await _dbContext.SaveChangesAsync();

        // Create the ItemsController using the in-memory database context.
        var controller = new ItemsController(_dbContext);

        // Act
        var result = await controller.DeleteItem(1);

        // Assert
        Assert.IsType<NoContentResult>(result);
    }

    [Fact]
    public async Task DeleteItem_WithInvalidId_ReturnsNotFoundResult()
    {
        // Arrange
        var item = new Item { Id = 1, Name = "Item 1", Description = "Description 1" };

        // Seed the in-memory database with the test item.
        await _dbContext.Database.EnsureDeletedAsync();
        await _dbContext.Database.EnsureCreatedAsync();
        await _dbContext.Items.AddAsync(item);
        await _dbContext.SaveChangesAsync();

        // Create the ItemsController using the in-memory database context.
        var controller = new ItemsController(_dbContext);

        // Act
        var result = await controller.DeleteItem(2);

        // Assert
        Assert.IsType<NotFoundResult>(result);
    }

    public void Dispose()
    {
        // Clean up the in-memory database after all tests have run.
        _dbContext.Dispose();
    }
}
