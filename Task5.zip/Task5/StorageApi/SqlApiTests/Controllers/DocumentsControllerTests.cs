﻿using Microsoft.AspNetCore.Mvc;
using Moq;
using NoSqlApi.Controllers;
using NoSqlApi.Interfaces;
using NoSqlApi.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

public class DocumentsControllerTests
{
    [Fact]
    public async Task GetAllDocuments_ReturnsOkResultWithListOfDocuments()
    {
        // Arrange
        var documents = new List<Document>
        {
            new Document {id = "18", Title = "Document 18" },
            new Document {id = "28", Title = "Document 28" }
        };

        var repositoryMock = new Mock<IDocumentRepository>();
        repositoryMock.Setup(repo => repo.GetAllDocumentsAsync()).ReturnsAsync(documents);

        var controller = new DocumentsController(repositoryMock.Object);

        // Act
        var result = await controller.GetAllDocuments();

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var model = Assert.IsAssignableFrom<IEnumerable<Document>>(okResult.Value);
        Assert.Equal(2, model.Count());
    }

    [Fact]
    public async Task GetDocument_WithValidId_ReturnsOkResultWithDocument()
    {
        // Arrange
        var documentId = "18";
        var document = new Document { id = documentId, Title = "Document 18" };

        var repositoryMock = new Mock<IDocumentRepository>();
        repositoryMock.Setup(repo => repo.GetDocumentAsync(documentId)).ReturnsAsync(document);

        var controller = new DocumentsController(repositoryMock.Object);

        // Act
        var result = await controller.GetDocument(documentId);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var model = Assert.IsType<Document>(okResult.Value);
        Assert.Equal(documentId, model.id);
    }

    [Fact]
    public async Task GetDocument_WithInvalidId_ReturnsNotFoundResult()
    {
        // Arrange
        var invalidDocumentId = "999";

        var repositoryMock = new Mock<IDocumentRepository>();
        repositoryMock.Setup(repo => repo.GetDocumentAsync(invalidDocumentId)).ReturnsAsync((Document)null);

        var controller = new DocumentsController(repositoryMock.Object);

        // Act
        var result = await controller.GetDocument(invalidDocumentId);

        // Assert
        Assert.IsType<NotFoundResult>(result.Result);
    }


    [Fact]
    public async Task CreateDocument_WithValidDocument_ReturnsCreatedAtActionResult()
    {
        // Arrange
        var documentId = "some-document-id";
        var document = new Document { id = documentId };

        var repositoryMock = new Mock<IDocumentRepository>();
        repositoryMock.Setup(repo => repo.CreateDocumentAsync(document)).Returns(Task.CompletedTask);

        var controller = new DocumentsController(repositoryMock.Object);

        // Act
        var result = await controller.CreateDocument(document);

        // Assert
        Assert.NotNull(result); // Check if the result is not null
        Assert.IsType<ActionResult<Document>>(result); // Check if the result is an instance of ActionResult<Document>
        var createdAtActionResult = Assert.IsType<CreatedAtActionResult>(result.Result); // Check the inner result
        Assert.Equal(document, createdAtActionResult.Value); // Verify the value returned in the CreatedAtActionResult
    }


    [Fact]
    public async Task UpdateDocument_WithValidDocument_ReturnsNoContentResult()
    {
        // Arrange
        var documentId = "18";
        var document = new Document { id = documentId, Title = "Updated Document" };

        var repositoryMock = new Mock<IDocumentRepository>();
        repositoryMock.Setup(repo => repo.GetDocumentAsync(documentId)).ReturnsAsync(document);
        repositoryMock.Setup(repo => repo.UpdateDocumentAsync(document)).Returns(Task.CompletedTask);

        var controller = new DocumentsController(repositoryMock.Object);

        // Act
        var result = await controller.UpdateDocument(documentId, document);

        // Assert
        Assert.IsType<NoContentResult>(result);
    }

    [Fact]
    public async Task UpdateDocument_WithInvalidDocument_ReturnsBadRequestResult()
    {
        // Arrange
        var invalidDocumentId = "999";
        var document = new Document { id = "18", Title = "Updated Document" };

        var repositoryMock = new Mock<IDocumentRepository>();
        repositoryMock.Setup(repo => repo.GetDocumentAsync(invalidDocumentId)).ReturnsAsync((Document)null);

        var controller = new DocumentsController(repositoryMock.Object);

        // Act
        var result = await controller.UpdateDocument(invalidDocumentId, document);

        // Assert
        Assert.IsType<BadRequestResult>(result); 
    }



    [Fact]
    public async Task DeleteDocument_WithValidId_ReturnsNoContentResult()
    {
        // Arrange
        var documentId = "18";
        var document = new Document { id = documentId, Title = "Document 18" };

        var repositoryMock = new Mock<IDocumentRepository>();
        repositoryMock.Setup(repo => repo.GetDocumentAsync(documentId)).ReturnsAsync(document);
        repositoryMock.Setup(repo => repo.DeleteDocumentAsync(documentId)).Returns(Task.CompletedTask);

        var controller = new DocumentsController(repositoryMock.Object);

        // Act
        var result = await controller.DeleteDocument(documentId);

        // Assert
        Assert.IsType<NoContentResult>(result);
    }

    [Fact]
    public async Task DeleteDocument_WithInvalidId_ReturnsNotFoundResult()
    {
        // Arrange
        var invalidDocumentId = "999";

        var repositoryMock = new Mock<IDocumentRepository>();
        repositoryMock.Setup(repo => repo.GetDocumentAsync(invalidDocumentId)).ReturnsAsync((Document)null);

        var controller = new DocumentsController(repositoryMock.Object);

        // Act
        var result = await controller.DeleteDocument(invalidDocumentId);

        // Assert
        Assert.IsType<NotFoundResult>(result);
    }
}
