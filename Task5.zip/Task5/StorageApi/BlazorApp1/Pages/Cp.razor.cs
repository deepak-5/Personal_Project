﻿using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Components;
using BlazorApp1.Data;

namespace BlazorApp1.Pages
{
    public partial class Cp : ComponentBase
    {
        private List<Item> items;
        private Item newItem = new Item();
        private Item selectedItem;

        [Inject]
        private HttpClient HttpClient { get; set; }

        protected override async Task OnInitializedAsync()
        {
            await LoadItems();
        }

        private async Task LoadItems()
        {
            items = await HttpClient.GetFromJsonAsync<List<Item>>("https://task18.azurewebsites.net/api/items");
        }

        private async Task CreateItem()
        {
            var response = await HttpClient.PostAsJsonAsync("https://task18.azurewebsites.net/api/items", newItem);
            response.EnsureSuccessStatusCode();
            await LoadItems();
            newItem = new Item();
        }

        private async Task EditItem(Item item)
        {
            selectedItem = item;
        }

        private async Task UpdateItem()
        {
            var response = await HttpClient.PutAsJsonAsync($"https://task18.azurewebsites.net/api/items/{selectedItem.Id}", selectedItem);
            response.EnsureSuccessStatusCode();
            selectedItem = null;
            await LoadItems();
        }

        private async Task DeleteItem(int id)
        {
            var response = await HttpClient.DeleteAsync($"https://task18.azurewebsites.net/api/items/{id}");
            response.EnsureSuccessStatusCode();
            await LoadItems();
        }
    }
}
