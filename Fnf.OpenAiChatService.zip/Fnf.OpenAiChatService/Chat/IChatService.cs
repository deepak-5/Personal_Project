﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fnf.OpenAiChatService.Chat
{
    public interface IChatService
    {
        Task<string> GetResponseAsync(string userInput);
    }
}
