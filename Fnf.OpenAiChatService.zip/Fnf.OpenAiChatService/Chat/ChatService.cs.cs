﻿using Azure.AI.OpenAI;
using Microsoft.SemanticKernel.ChatCompletion;
using Microsoft.SemanticKernel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fnf.OpenAiChatService.Chat
{
    public class ChatService : IChatService
    {
        private readonly IChatCompletionService _chatCompletionService;
        private readonly ChatHistory _chatHistory;
        private readonly Kernel _kernel;  // Declare kernel as a member variable

        public ChatService(string deploymentName, AzureOpenAIClient client)
        {
            // Build the kernel and chat completion service
            IKernelBuilder kernelBuilder = Kernel.CreateBuilder();
            kernelBuilder.AddAzureOpenAIChatCompletion(
                deploymentName: deploymentName, // Use the parameter passed to the constructor
                azureOpenAIClient: client // Use the parameter passed to the constructor
            );
            this._kernel = kernelBuilder.Build();  // Assign to the member variable
            this._chatCompletionService = this._kernel.GetRequiredService<IChatCompletionService>();

            // Initialize chat history
            this._chatHistory = new ChatHistory();
            this._chatHistory.AddSystemMessage(@"

                        **Prompt:**  
                        ""Analyze the two CSV datasets provided (Ground Truth and LLM Response). Your task is to compare them and output a JSON report as specified. Follow these rules:  

                        ### **Comparison Rules:**  
                        1. **Page Ranges (Primary Check):**  
                           - For each entry in **Ground Truth (CSV1)**, check if there exists a corresponding entry in **LLM Response (CSV2)** with **EXACTLY THE SAME Actual Start Page and Actual End Page**.  
                           - If found:  
                             - If the **Actual Doc Title** differs, mark the entry as `True` (valid) and add a comment noting the title discrepancy.  
                             - If titles match, mark as `True` with no comment.  
                           - If **NO** matching entry exists in CSV2:  
                             - Check if the LLM has **split the document into parts** (e.g., same base title with suffixes like `-A1`, `-A2`, etc.) and the **start/end pages of these parts collectively cover the Ground Truth’s range**.  
                             - If yes: Mark as `True` and add a comment like `""Split into parts with correct page ranges""`.  
                             - If not: Mark as `False` (error) and note the missing page range.  

                        2. **Extra Entries in LLM Response:**  
                           - Any entry in CSV2 without a matching Ground Truth entry (and not part of a valid split) is an **error**.  

                        3. **Page Range Errors:**  
                           - If start/end pages **do not align** (e.g., `Ground Truth: 13-14` vs `LLM: 13-16`), mark as `False` and specify the discrepancy.  

                        ### **Output Format:**  
                        Generate a JSON object with the following structure:  
                        ```json  
                        [{  
                          ""{start-page}-{end-page}"": ""True/False"", // Validity of page range  
                          ""{Document-Title}"": ""True/False"", // Validity of title (if pages are correct)  
                          ""Comments"": [  
                            ""Comment 1 (if applicable)"",  
                            ""Comment 2 (if applicable)"", ...  
                          ]  
                        },
{  
                          ""{start-page}-{end-page}"": ""True/False"", // Validity of page range  
                          ""{Document-Title}"": ""True/False"", // Validity of title (if pages are correct)  
                          ""Comments"": [  
                            ""Comment 1 (if applicable)"",  
                            ""Comment 2 (if applicable)"", ...  
                          ]  
                        },
                     ...... ] 
                        ```  

                        ### **Examples to Follow:**  
                        - **Valid Split Example:**  
                          Ground Truth: `8-12` → LLM splits into `8-9`, `9-9`, `10-10`, `11-12` → **Valid** (mark as `True` with title comment).  
                        - **Invalid Example:**  
                          Ground Truth: `13-14` → LLM has `13-16` → **Error** (mark `False` for `13-16`).  

                        ### **Notes:**  
                        - Ignore `Sr. No.` and `Total Pages` (focus on titles and page numbers).  
                        - Prioritize page range accuracy over title matches.  

                        **Output ONLY the JSON report.**""  

                        ---");
        }

        public async Task<string> GetResponseAsync(string userInput)
        {
            // Add the user input to the chat history
            this._chatHistory.AddUserMessage(userInput);

            // Get the assistant response
            var results = await this._chatCompletionService.GetChatMessageContentAsync(
                this._chatHistory,
                kernel: this._kernel  // Use the member variable here
            ).ConfigureAwait(false);

            // Add the assistant response content to the chat history
            this._chatHistory.AddAssistantMessage(results.Content!);

            return results.Content!;
        }
    }
}
