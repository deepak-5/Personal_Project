﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fnf.OpenAiChatService.DirectChat
{
    public interface IDirectResponseService
    {
        Task<string> GetDirectResponseAsync(string userRequest, string systemMessage);
    }
}
