﻿using Azure.AI.OpenAI;
using Microsoft.SemanticKernel.ChatCompletion;
using Microsoft.SemanticKernel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fnf.OpenAiChatService.DirectChat
{
    public class DirectResponseService : IDirectResponseService
    {
        private readonly IChatCompletionService _chatCompletionService;
        private readonly Kernel _kernel;

        public DirectResponseService(string deploymentName, AzureOpenAIClient client)
        {
            // Build the kernel and chat completion service
            IKernelBuilder kernelBuilder = Kernel.CreateBuilder();
            kernelBuilder.AddAzureOpenAIChatCompletion(
                deploymentName: deploymentName, // Use the parameter passed to the constructor
                azureOpenAIClient: client // Use the parameter passed to the constructor
            );
            this._kernel = kernelBuilder.Build();  // Assign to the member variable
            this._chatCompletionService = this._kernel.GetRequiredService<IChatCompletionService>();
        }

        public async Task<string> GetDirectResponseAsync(string userInput, string systemMessage)
        {
            var chatHistory = new Microsoft.SemanticKernel.ChatCompletion.ChatHistory();
            if (systemMessage is not null)
            {
                chatHistory.AddSystemMessage(systemMessage);
            }
            else
            {
                chatHistory.AddSystemMessage("You are a helpful assistant.");
            }
            chatHistory.AddUserMessage(userInput);

            var results = await this._chatCompletionService.GetChatMessageContentAsync(
                chatHistory,
                kernel: this._kernel
            ).ConfigureAwait(false);

            return results.Content;
        }
    }
}
