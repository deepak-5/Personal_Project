﻿using Microsoft.AspNetCore.SignalR;

public class RequestLoggerMiddleware
{
    private readonly RequestDelegate _next;
    private readonly IHubContext<NotificationHub> _hubContext;

    public RequestLoggerMiddleware(RequestDelegate next, IHubContext<NotificationHub> hubContext)
    {
        _next = next;
        _hubContext = hubContext;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        // Log information about the incoming request
        Console.WriteLine($"Request received at {DateTime.Now}: {context.Request.Path}");

        // Process incoming notifications from SignalR
        if (context.Request.Path == "/notification")
        {
            string message = context.Request.Query["message"];
            // Process the notification, e.g., log it
            Console.WriteLine($"Notification received: {message}");
        }

        await _next(context);
    }
}
