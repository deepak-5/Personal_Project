﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration; // Import IConfiguration

namespace MyJwtAuthApp.Controllers
{
    [Route("api/auth")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IConfiguration _configuration; // Add IConfiguration field

        public AuthController(IConfiguration configuration) // Inject IConfiguration in the constructor
        {
            _configuration = configuration;
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] User user)
        {
            // Check user credentials (e.g., in a database)
            if (user.Username == "demo" && user.Password == "password")
            {
                var token = JwtHelper.GenerateJwtToken(user.Username, _configuration["Jwt:SecretKey"]); // Use _configuration
                return Ok(new { Token = token });
            }

            return Unauthorized();
        }
    }
}
