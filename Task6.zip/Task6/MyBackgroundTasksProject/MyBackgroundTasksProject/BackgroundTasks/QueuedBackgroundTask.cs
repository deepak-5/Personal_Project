﻿using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;

namespace MyBackgroundTasksProject.BackgroundTasks
{
    public class QueuedBackgroundTask
    {
        private ConcurrentQueue<string> taskQueue = new ConcurrentQueue<string>();
        private CancellationTokenSource _cancellationTokenSource;

        public void EnqueueTask(string task)
        {
            taskQueue.Enqueue(task);
        }

        public async Task StartAsync()
        {
            _cancellationTokenSource = new CancellationTokenSource();

            while (!_cancellationTokenSource.Token.IsCancellationRequested)
            {
                if (taskQueue.TryDequeue(out string task))
                {
                    Console.WriteLine($"QueuedBackgroundTask is processing: {task}");
                    // Perform the task's work here
                }
                await Task.Delay(1000, _cancellationTokenSource.Token); // Check for new tasks every second or until canceled
            }
        }

        public void Stop()
        {
            _cancellationTokenSource.Cancel();
        }
    }
}
