﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace MyBackgroundTasksProject.BackgroundTasks
{
    public class TimedBackgroundTask
    {
        private CancellationTokenSource _cancellationTokenSource;

        public async Task StartAsync()
        {
            _cancellationTokenSource = new CancellationTokenSource();

            while (!_cancellationTokenSource.Token.IsCancellationRequested)
            {
                Console.WriteLine("TimedBackgroundTask is running...");
                await Task.Delay(2000, _cancellationTokenSource.Token); // Run every 2 seconds or until canceled
            }
        }

        public void Stop()
        {
            _cancellationTokenSource.Cancel();
        }
    }
}
