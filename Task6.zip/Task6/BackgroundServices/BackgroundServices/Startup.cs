﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Configuration;
using BackgroundServices.Application.UseCases.ScopedBackgroundTask;
using BackgroundServices.Application.UseCases.TimedBackgroundTask;
using BackgroundServices.Application.UseCases.AsyncTimedBackgroundTask;
using BackgroundServices.Application.UseCases.QueuedBackgroundTask;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Mvc;
using BackgroundServices.Infrastructure.BackgroundTasks;
using BackgroundServices.Domain.Services;
using BackgroundServices.Web.Controllers;

namespace BackgroundServices
{
    public class Startup
    {
        private readonly IConfiguration _configuration;

        public Startup(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            // Configure your services here

            // Logging configuration
            services.AddLogging(builder =>
            {
                builder.AddConsole();
                builder.SetMinimumLevel(LogLevel.Information); // Adjust the log level as needed
            });

            // Scoped service registration
            services.AddScoped<IScopedBackgroundTaskService, ScopedBackgroundTaskService>();

            // Timed background task registration
            services.AddSingleton<IHostedService, BackgroundServices.Application.UseCases.TimedBackgroundTask.TimedBackgroundTaskService>();

            // Async timed background task registration
            services.AddSingleton<IHostedService, BackgroundServices.Application.UseCases.AsyncTimedBackgroundTask.AsyncTimedBackgroundTaskService>();

            // Queued background task registration
            services.AddSingleton<QueuedBackgroundTask>();

            // Register the QueuedBackgroundService
            services.AddScoped<IQueuedBackgroundService, QueuedBackgroundService>();

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_3_0);

            // Configure other services, authentication, database, etc.
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, IServiceProvider serviceProvider)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // Configure production settings
            }

            // Configure your application middleware, authentication, routing, etc.
            app.UseRouting();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            // Ensure database migrations and other setup if needed
            // Use serviceProvider to access services or run any initialization logic
        }
    }
}
