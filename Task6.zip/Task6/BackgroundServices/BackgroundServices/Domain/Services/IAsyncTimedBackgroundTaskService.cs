﻿using System.Threading.Tasks;

namespace BackgroundServices.Domain.Services
{
    public interface IAsyncTimedBackgroundTaskService
    {
        Task StartAsyncTimedBackgroundTaskAsync();
    }
}
