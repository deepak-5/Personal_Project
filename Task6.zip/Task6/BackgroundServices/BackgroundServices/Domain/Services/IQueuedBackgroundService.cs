﻿using System.Threading.Tasks;

namespace BackgroundServices.Domain.Services
{
    public interface IQueuedBackgroundService
    {
        Task EnqueueTaskAsync(string taskData);
    }
}
