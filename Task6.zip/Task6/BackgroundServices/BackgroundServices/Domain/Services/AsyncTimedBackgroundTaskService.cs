﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using BackgroundServices.Domain.Services;

namespace BackgroundServices.Domain.Services
{
    public class AsyncTimedBackgroundTaskService : IAsyncTimedBackgroundTaskService, IHostedService, IDisposable
    {
        private readonly ILogger<AsyncTimedBackgroundTaskService> _logger;
        private Timer _timer;

        public AsyncTimedBackgroundTaskService(ILogger<AsyncTimedBackgroundTaskService> logger)
        {
            _logger = logger;
        }

        public Task StartAsyncTimedBackgroundTaskAsync()
        {
            _logger.LogInformation("Async Timed Background Task is starting.");

            // Adjust the interval as needed (e.g., TimeSpan.FromMinutes(5))
            _timer = new Timer(DoAsyncTimedWork, null, TimeSpan.Zero, TimeSpan.FromMinutes(5));

            return Task.CompletedTask;
        }

        private void DoAsyncTimedWork(object state)
        {
            _logger.LogInformation("Async timed background task is doing some work.");

            // Implement your asynchronous timed task logic here

            _logger.LogInformation("Async timed background task work is complete.");
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            // Not used in this service
            return Task.CompletedTask;
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Async Timed Background Task is stopping.");

            _timer?.Change(Timeout.Infinite, 0);
            return Task.CompletedTask;
        }

        public void Dispose()
        {
            _timer?.Dispose();
        }
    }
}
