﻿using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace BackgroundServices.Domain.Services
{
    public class ScopedService : IScopedService
    {
        private readonly ILogger<ScopedService> _logger;

        public ScopedService(ILogger<ScopedService> logger)
        {
            _logger = logger;
        }

        public async Task DoWorkAsync()
        {
            // Implement the logic for your scoped service.
            _logger.LogInformation("Scoped service is doing some work.");
            await Task.Delay(TimeSpan.FromSeconds(10));
            _logger.LogInformation("Scoped service work is complete.");
        }
    }
}
