﻿using System.Threading.Tasks;
using BackgroundServices.Infrastructure.BackgroundTasks; // Import the appropriate namespace for the background task


namespace BackgroundServices.Domain.Services
{
    public class QueuedBackgroundService : IQueuedBackgroundService
    {
        private readonly QueuedBackgroundTask _queuedBackgroundTask;

        public QueuedBackgroundService(QueuedBackgroundTask queuedBackgroundTask)
        {
            _queuedBackgroundTask = queuedBackgroundTask;
        }

        public async Task EnqueueTaskAsync(string taskData)
        {
            // Enqueue a task for processing in the background task
            _queuedBackgroundTask.EnqueueTask(taskData);
            await Task.CompletedTask;
        }
    }
}
