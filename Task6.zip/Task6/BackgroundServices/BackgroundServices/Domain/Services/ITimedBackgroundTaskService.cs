﻿using System.Threading.Tasks;

namespace BackgroundServices.Domain.Services
{
    public interface ITimedBackgroundTaskService
    {
        Task StartTimedBackgroundTaskAsync();
    }
}
