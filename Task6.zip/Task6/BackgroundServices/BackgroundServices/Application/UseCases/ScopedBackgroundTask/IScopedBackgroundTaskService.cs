﻿using System.Threading.Tasks;

namespace BackgroundServices.Application.UseCases.ScopedBackgroundTask
{
    public interface IScopedBackgroundTaskService
    {
        Task ExecuteScopedTask();
    }
}
