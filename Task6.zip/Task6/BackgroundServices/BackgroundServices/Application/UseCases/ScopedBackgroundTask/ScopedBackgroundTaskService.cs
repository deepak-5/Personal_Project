﻿using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace BackgroundServices.Application.UseCases.ScopedBackgroundTask
{
    public class ScopedBackgroundTaskService : IScopedBackgroundTaskService, IHostedService, IDisposable
    {
        private readonly ILogger<ScopedBackgroundTaskService> _logger;
        private Timer _timer;

        public ScopedBackgroundTaskService(ILogger<ScopedBackgroundTaskService> logger)
        {
            _logger = logger;
        }

        public Task ExecuteScopedTask()
        {
            // Implement your scoped task logic here
            _logger.LogInformation("Scoped background task is doing some work.");
            return Task.CompletedTask;
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Scoped Background Task is starting.");
            _timer = new Timer(DoScopedWork, null, TimeSpan.Zero, TimeSpan.FromSeconds(30)); // Adjust the interval as needed
            return Task.CompletedTask;
        }

        private void DoScopedWork(object state)
        {
            ExecuteScopedTask();
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Scoped Background Task is stopping.");
            _timer?.Change(Timeout.Infinite, 0);
            return Task.CompletedTask;
        }

        public void Dispose()
        {
            _timer?.Dispose();
        }
    }
}
