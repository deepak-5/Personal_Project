﻿namespace BackgroundServices.Application.UseCases.Authentication
{
    public class JwtService
    {
    }
}
