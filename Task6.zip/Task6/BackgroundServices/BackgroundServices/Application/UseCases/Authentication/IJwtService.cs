﻿namespace BackgroundServices.Application.UseCases.Authentication
{
    public interface IJwtService
    {
    }
}
