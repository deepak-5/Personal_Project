﻿using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;

namespace BackgroundServices.Application.UseCases.QueuedBackgroundTask
{
    public class QueuedBackgroundTaskService : IQueuedBackgroundTaskService, IHostedService, IDisposable
    {
        private readonly ILogger<QueuedBackgroundTaskService> _logger;
        private readonly ConcurrentQueue<string> _tasks = new ConcurrentQueue<string>();
        private Timer _timer;

        public QueuedBackgroundTaskService(ILogger<QueuedBackgroundTaskService> logger)
        {
            _logger = logger;
        }

        public void EnqueueTask(string taskData)
        {
            if (!string.IsNullOrEmpty(taskData))
            {
                _tasks.Enqueue(taskData);
                _logger.LogInformation("Queued task added. Total tasks in queue: " + _tasks.Count);
            }
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Queued Background Task is starting.");

            _timer = new Timer(DoQueuedWork, null, TimeSpan.Zero, TimeSpan.FromSeconds(5)); // Adjust the interval as needed

            return Task.CompletedTask;
        }

        private void DoQueuedWork(object state)
        {
            if (_tasks.TryDequeue(out string taskData))
            {
                _logger.LogInformation("Processing queued task: " + taskData);
            }
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Queued Background Task is stopping.");

            _timer?.Change(Timeout.Infinite, 0);
            return Task.CompletedTask;
        }

        public void Dispose()
        {
            _timer?.Dispose();
        }
    }
}
