﻿namespace BackgroundServices.Application.UseCases.QueuedBackgroundTask
{
    public interface IQueuedBackgroundTaskService
    {
        void EnqueueTask(string taskData);
    }
}
