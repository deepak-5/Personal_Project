﻿using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace BackgroundServices.Application.UseCases.AsyncTimedBackgroundTask
{
    public class AsyncTimedBackgroundTaskService : IAsyncTimedBackgroundTaskService, IHostedService, IDisposable
    {
        private readonly ILogger<AsyncTimedBackgroundTaskService> _logger;
        private Timer _timer;

        public AsyncTimedBackgroundTaskService(ILogger<AsyncTimedBackgroundTaskService> logger)
        {
            _logger = logger;
        }

        public Task ExecuteAsyncTimedTask()
        {
            // Implement your asynchronous timed task logic here
            _logger.LogInformation("Async timed background task is doing some work.");
            return SomeAsyncOperation();
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Async Timed Background Task is starting.");
            _timer = new Timer(DoAsyncTimedWork, null, TimeSpan.Zero, TimeSpan.FromMinutes(10)); // Adjust the interval as needed
            return Task.CompletedTask;
        }

        private async void DoAsyncTimedWork(object state)
        {
            await ExecuteAsyncTimedTask();
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Async Timed Background Task is stopping.");
            _timer?.Change(Timeout.Infinite, 0);
            return Task.CompletedTask;
        }

        public void Dispose()
        {
            _timer?.Dispose();
        }

        private async Task SomeAsyncOperation()
        {
            // Implement your asynchronous task logic here
            await Task.Delay(1000); // Placeholder for a time-consuming asynchronous operation
        }
    }
}
