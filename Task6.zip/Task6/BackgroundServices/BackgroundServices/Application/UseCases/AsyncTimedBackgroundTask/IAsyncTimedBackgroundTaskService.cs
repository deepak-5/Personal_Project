﻿using System.Threading.Tasks;

namespace BackgroundServices.Application.UseCases.AsyncTimedBackgroundTask
{
    public interface IAsyncTimedBackgroundTaskService
    {
        Task ExecuteAsyncTimedTask();
    }
}
