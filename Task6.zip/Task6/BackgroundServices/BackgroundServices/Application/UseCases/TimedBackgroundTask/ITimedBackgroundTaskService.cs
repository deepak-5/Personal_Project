﻿using System.Threading.Tasks;

namespace BackgroundServices.Application.UseCases.TimedBackgroundTask
{
    public interface ITimedBackgroundTaskService
    {
        Task ExecuteTimedTask();
    }
}
