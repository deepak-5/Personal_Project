﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace BackgroundServices.Infrastructure.BackgroundTasks
{
    public class AsyncTimedBackgroundTask : IHostedService, IDisposable
    {
        private readonly ILogger<AsyncTimedBackgroundTask> _logger;
        private Timer _timer;

        public AsyncTimedBackgroundTask(ILogger<AsyncTimedBackgroundTask> logger)
        {
            _logger = logger;
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Async Timed Background Task is starting.");

            // Adjust the interval as needed (e.g., TimeSpan.FromMinutes(5))
            _timer = new Timer(DoAsyncTimedWork, null, TimeSpan.Zero, TimeSpan.FromMinutes(5));

            return Task.CompletedTask;
        }

        private void DoAsyncTimedWork(object state)
        {
            _logger.LogInformation("Async timed background task is doing some work.");

            // Implement your asynchronous timed task logic here

            _logger.LogInformation("Async timed background task work is complete.");
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Async Timed Background Task is stopping.");

            _timer?.Change(Timeout.Infinite, 0);
            return Task.CompletedTask;
        }

        public void Dispose()
        {
            _timer?.Dispose();
        }
    }
}
