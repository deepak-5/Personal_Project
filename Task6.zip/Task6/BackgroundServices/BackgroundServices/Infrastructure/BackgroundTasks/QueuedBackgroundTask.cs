﻿using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace BackgroundServices.Infrastructure.BackgroundTasks
{
    public class QueuedBackgroundTask : BackgroundService
    {
        private readonly ILogger<QueuedBackgroundTask> _logger;
        private readonly ConcurrentQueue<string> _taskQueue = new ConcurrentQueue<string>();

        public QueuedBackgroundTask(ILogger<QueuedBackgroundTask> logger)
        {
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                while (_taskQueue.TryDequeue(out string taskData))
                {
                    _logger.LogInformation("Queued background task is processing: " + taskData);

                    // Implement your queued task logic here

                    _logger.LogInformation("Queued background task processing is complete.");
                }

                await Task.Delay(TimeSpan.FromMinutes(5), stoppingToken); // Adjust the interval as needed
            }
        }

        public void EnqueueTask(string taskData)
        {
            _taskQueue.Enqueue(taskData);
        }
    }
}
