﻿namespace BackgroundServices.Infrastructure.BackgroundTasks
{
    public class ScopedBackgroundTask
    {
    }
}
