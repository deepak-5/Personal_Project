﻿using Microsoft.AspNetCore.Mvc;
using BackgroundServices.Application.UseCases.AsyncTimedBackgroundTask;
using System.Threading.Tasks;

namespace BackgroundServices.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AsyncTimedBackgroundTaskController : ControllerBase
    {
        private readonly IAsyncTimedBackgroundTaskService _asyncTimedBackgroundTaskService;

        public AsyncTimedBackgroundTaskController(IAsyncTimedBackgroundTaskService asyncTimedBackgroundTaskService)
        {
            _asyncTimedBackgroundTaskService = asyncTimedBackgroundTaskService;
        }

        [HttpPost("start")]
        public async Task<IActionResult> StartAsyncTimedBackgroundTask()
        {
            await _asyncTimedBackgroundTaskService.DoAsyncTimedWorkAsync();
            return Ok("Async timed background task has been manually triggered.");
        }
    }
}
