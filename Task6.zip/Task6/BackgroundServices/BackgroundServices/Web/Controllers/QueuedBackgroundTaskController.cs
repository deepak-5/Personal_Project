﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using BackgroundServices.Domain.Services;

namespace BackgroundServices.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class QueuedBackgroundTaskController : ControllerBase
    {
        private readonly IQueuedBackgroundService _queuedBackgroundService;

        public QueuedBackgroundTaskController(IQueuedBackgroundService queuedBackgroundService)
        {
            _queuedBackgroundService = queuedBackgroundService;
        }

        [HttpPost("enqueue")]
        public async Task<IActionResult> EnqueueTask([FromBody] string taskData)
        {
            try
            {
                await _queuedBackgroundService.EnqueueTaskAsync(taskData);
                return Ok("Task enqueued successfully.");
            }
            catch (Exception ex)
            {
                return BadRequest($"Failed to enqueue task: {ex.Message}");
            }
        }
    }
}
