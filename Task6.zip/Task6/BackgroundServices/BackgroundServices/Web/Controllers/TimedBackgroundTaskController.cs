﻿using Microsoft.AspNetCore.Mvc;
using BackgroundServices.Application.UseCases.TimedBackgroundTask;
using System.Threading.Tasks;

namespace BackgroundServices.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TimedBackgroundTaskController : ControllerBase
    {
        private readonly ITimedBackgroundTaskService _timedBackgroundTaskService;

        public TimedBackgroundTaskController(ITimedBackgroundTaskService timedBackgroundTaskService)
        {
            _timedBackgroundTaskService = timedBackgroundTaskService;
        }

        [HttpPost("start")]
        public async Task<IActionResult> StartTimedBackgroundTask()
        {
            await _timedBackgroundTaskService.DoTimedWorkAsync();
            return Ok("Timed background task has been manually triggered.");
        }
    }
}
