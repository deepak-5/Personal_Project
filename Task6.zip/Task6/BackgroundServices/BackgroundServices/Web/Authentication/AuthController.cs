﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using System;
using System.Threading.Tasks;

namespace BackgroundServices.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly ILogger<AuthController> _logger;

        public AuthController(ILogger<AuthController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        [Authorize] // Requires authorization
        public IActionResult GetAuthorized()
        {
            _logger.LogInformation("AuthController - GetAuthorized method called.");
            return Ok("Hello from AuthController (Authorized)!");
        }

        [HttpGet("public")]
        public IActionResult GetPublic()
        {
            _logger.LogInformation("AuthController - GetPublic method called.");
            return Ok("Hello from AuthController (Public)!");
        }
    }
}
