using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MiddlewareDemo.Pages
{
    public class NotificationModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
